ALTER TABLE `Contact`
	MODIFY `employee_id` VARCHAR(32);
